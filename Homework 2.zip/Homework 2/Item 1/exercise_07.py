#Exercise 7

class Car:

    def __init__(self,year=0, make="", model=""):
        self.year = 2019-year
        self.make = make
        self.model = model


mycar = Car(1970, "","Volkswagen Beetle")
print(mycar.year)