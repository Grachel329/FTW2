#Exercise 6

# Challenge - Dictionaries Exercise
#
# Given two lists - words and definitions,
# Create a dictionary called cooldictionary where you
# use words for keys and definitions for values

cooldictionary = {"PoGo":"Slang for Pokemon Go", "Spange":"To collect spare change, either from couches, passerbys on the street or any numerous other ways and means", "Lie-Fi":"When your phone or tablet indicates that you are connected to a wireless network, however you are still unable to load webpages or use any internet services with your device"}
print(cooldictionary)
print("\n")
print(cooldictionary["PoGo"])
print("\n")
print(cooldictionary["Spange"])
print("\n")
print(cooldictionary["Lie-Fi"])