#Exercise 3

def tripleprint(name):
	print("{}".format(name)*3)

tripleprint("hello")