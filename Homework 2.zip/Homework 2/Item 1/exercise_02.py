#Exercise 2

year = 1830

if 2000<=year<=2100:
	print("Welcome to the 21st century.")
else:
	print("You are before or after the 21st century.")