#Exercise 4

shoes = ["Spizikes", "Air Force 1", "Curry 2", "Melo 5"]
for shoename in shoes:
	print(shoename)