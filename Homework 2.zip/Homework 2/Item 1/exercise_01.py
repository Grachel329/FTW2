#Exercise 1

name = "Julie"
age = 42

sentence="Hi my name is {} and I am {} years old.".format(name,age)
print(sentence)